import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marketing',
  templateUrl: './marketing.component.html',
  styleUrls: ['./marketing.component.sass']
})
export class MarketingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
