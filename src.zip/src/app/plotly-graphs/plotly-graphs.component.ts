import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plotly-graphs',
  templateUrl: './plotly-graphs.component.html',
  styleUrls: ['./plotly-graphs.component.sass'],
  
})
export class PlotlyGraphsComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {
  }
graphs = {
data: [
  { x: [1, 2, 3,4], y: [2, 6, 3,6], type: 'scatter', mode: 'lines+points', marker: {color: 'green'} },
],
  layout: {width: 350, height: 340, title: 'basic line'} };

     grapha = {
       data: [
      { x: [1, 3, 6], y: [2, 6, 3], type: 'bar', mode: 'lines', marker: {color: 'green'} },
      
      { x: [2, 2, 3], y: [2, 3, 3], type: 'scatter',  mode: 'lines', marker: {color: 'blue'}},
      { x: [3, 2, 3], y: [2, 5, 3], type: 'bar', mode: 'lines', marker: {color: 'pink'}}
    ],
    layout: {width: 400, height: 440, title: 'BarChart'}
  };

  piecharts={
   data : [{
      values: [16, 15, 12, 6, 5, 4, 42],
      labels: ['US', 'China', 'European Union', 'Russian Federation', 'Brazil', 'India', 'Rest of World' ],
      domain: {column: 0},
      name: 'GHG Emissions',
      hoverinfo: 'label+percent+name',
      hole: .4,
      type: 'pie'
    }],
    layout : {
      title: 'Global Emissions 1990-2011',
      annotations: [
        {
          font: {
            size: 15
          },
          showarrow: false,
          text: 'PieChart',
          x: 0.17,
          y: 0.5
        }
      ],
      height: 400,
      width: 600,
      showlegend: false,
      grid: {rows: 1, columns: 2}
    }
  }   
}
