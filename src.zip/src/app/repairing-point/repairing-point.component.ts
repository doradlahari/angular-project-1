import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-repairing-point',
  templateUrl: './repairing-point.component.html',
  styleUrls: ['./repairing-point.component.sass']
})
export class RepairingPointComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
